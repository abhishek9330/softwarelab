**pip install flask**

Then run the following command,
***python main.py***

I Have built two webpages using flask as the backend. main.py contains the route-handling and the assets 
and other files can be found in static and templates.

